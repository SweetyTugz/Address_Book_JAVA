package com.administrate.connection;

public class DataQuery {
	private String searchOrganisation = "";
	private String deleteOrganisation = "";
	private String insertOrganisation = "";
	private String updateOrganisation = "";
	private String searchPerson = "";
	private String deletePerson = "";
	private String insertPerson = "";
	private String updatePerson = "";

	public String getUpdateOrganisation() {
		return updateOrganisation;
	}

	public void setUpdateOrganisation(String updateOrganisation) {
		this.updateOrganisation = updateOrganisation;
	}

	public String getDeleteOrganisation() {
		return deleteOrganisation;
	}

	public void setDeleteOrganisation(String deleteOrganisation) {
		this.deleteOrganisation = deleteOrganisation;
	}

	public String getSearchOrganisation() {
		return searchOrganisation;
	}

	public void setSearchOrganisation(String searchOrganisation) {
		this.searchOrganisation = searchOrganisation;
	}

	public String getInsertOrganisation() {
		return insertOrganisation;
	}

	public void setInsertOrganisation(String insertOrganisation) {
		this.insertOrganisation = insertOrganisation;
	}

	public String getSearchPerson() {
		return searchPerson;
	}

	public void setSearchPerson(String searchPerson) {
		this.searchPerson = searchPerson;
	}

	public String getDeletePerson() {
		return deletePerson;
	}

	public void setDeletePerson(String deletePerson) {
		this.deletePerson = deletePerson;
	}

	public String getInsertPerson() {
		return insertPerson;
	}

	public void setInsertPerson(String insertPerson) {
		this.insertPerson = insertPerson;
	}

	public String getUpdatePerson() {
		return updatePerson;
	}

	public void setUpdatePerson(String updatePerson) {
		this.updatePerson = updatePerson;
	}

}
